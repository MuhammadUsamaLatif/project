import { AppLoading } from 'expo';
import * as Font from 'expo-font';
import React, { Component } from 'react';
import { Platform, AsyncStorage, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppSwitchNavigator } from './src/navigation/SwitchNavigator/SwitchNavigator'
import store from './src/Redux/store';
import { Provider } from 'react-redux';
import LoadingIndicator from './src/screens/LoadingIndicator/LoadingIndicator'
// import { setCurrentUser, logoutUser } from './src/Redux/Actions/authActions';
// import setAuthToken from './src/utils/setAuthToken';
// import jwt_decode from "jwt-decode";

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoadingComplete: false,
      token: ''
    }
  }
  // componentWillMount() {
  //   // Check for token to keep user logged in
  //   AsyncStorage.getItem('jwtToken', (err, token) => {
  //     if (err) {
  //       console.log('Not found token :', err)
  //     } else {
  //       this.setState({ token })
  //     }
  //   })
  // }
  // componentDidMount() {
  //   const { token } = this.state
  //   // Set auth token header auth
  //   setAuthToken(token);
  //   // Decode token and get user info and exp
  //   const decoded = jwt_decode(token);
  //   // Set user and isAuthenticated
  //   this.props.dispatch(setCurrentUser(decoded));
  //   // Check for expired token
  //   const currentTime = Date.now() / 1000; // to get in milliseconds
  //   if (decoded.exp < currentTime) {
  //     // Logout user
  //     this.props.dispatch(logoutUser());
  //     // Redirect to login
  //     this.props.navigation.navigate('SignIn')
  //   }
  //   this.props.navigation.navigate('Home')
  // }
  loadResourcesAsync = async () => {
    await Promise.all([
      Font.loadAsync({
        ...Ionicons.font,
        'avenirltstd-heavy': require('./assets/fonts/AvenirLTStd/AvenirLTStd-Book.otf'),
        Roboto: require("native-base/Fonts/Roboto.ttf"),
        Roboto_medium: require("native-base/Fonts/Roboto_medium.ttf"),
      }),
    ]);
  }

  handleLoadingError = () => {
    console.log('Some error occured');
  }

  render() {
    const { isLoadingComplete } = this.state
    if (!isLoadingComplete && !this.props.skipLoadingScreen) {
      return (
        <AppLoading
          startAsync={this.loadResourcesAsync}
          onError={this.handleLoadingError}
          onFinish={() => this.setState({ isLoadingComplete: true })}
        >
          <LoadingIndicator />
        </AppLoading>
      );
    } else {
      return (
        <Provider store={store}>
          <View style={styles.container}>
            {/* <StatusBar barStyle="dark-content" backgroundColor="red" /> */}
            <AppSwitchNavigator />
          </View>
        </Provider>
      );
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    ...Platform.select({
      android: {
        backgroundColor: '#261010',
      }
    }),
  },
});
