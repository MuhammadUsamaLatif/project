import { Platform } from 'react-native';
import Home from './../../screens/Dashboard/Home';
import Support from '../../screens/Support/Support';
import CustomDrawerLogo from './../../screens/DrawerLogo/DrawerLogo';
import AllMovies from './../../screens/AllMovies/AllMovies';
import SignOut from './../../screens/Auth/SignOut';
import { createDrawerNavigator } from 'react-navigation';
import Complaint from '../../screens/Complaint/Complaint';
import OnDemandMovie from '../../screens/OnDemandMovies/OnDemandMovies';
// import Feedback from '../../screens/Feedback/Feedbakc';

const config = Platform.select({
    web: { headerMode: 'screen' },
    default: {},
});

export const appDrawerNavigator = createDrawerNavigator({
    Home: {
        screen: Home
    },
    Movies: {
        screen: AllMovies
    },
    OnDemandMovie,
    Support,
    Complaint,
    // Feedback,
    SignOut,
},
    {
        initialRouteName: 'Home',
        contentComponent: CustomDrawerLogo,
        flex: 1,
        drawerBackgroundColor: "#261010",
        contentOptions: {
            activeTintColor: '#000',
            inactiveTintColor: '#fff',
            activeBackgroundColor: '#DF0100',
            inactiveBackgroundColor: '#261010',
            labelStyle: {
                fontSize: 15,
                marginLeft: 10,
            },
        }
    },
    config
)