import { Platform } from 'react-native';
import { createSwitchNavigator, createAppContainer } from 'react-navigation';
import SignUp from './../../screens/Auth/SignUp';
import PaymentDetails from './../../screens/Auth/PaymentDetails';
import SignIn from './../../screens/Auth/SignIn';
import MovieDetails from './../../screens/Movies/MovieDetails';
import Complaint from './../../screens/Complaint/Complaint';
import { appDrawerNavigator } from './../DrawerNavigator/DrawerNavigator';
import OnDemandMovie from '../../screens/OnDemandMovies/OnDemandMovies';
import VidoeComp from '../../screens/Videos/Video';
import NVideo from '../../screens/Native-Video/NVideo';
const config = Platform.select({
    web: { headerMode: 'screen' },
    default: {},
});
const SignUpStack = createSwitchNavigator(
    {
        Home: {
            screen: appDrawerNavigator,
        },
        SignUp,
        PaymentDetails,
        Complaint,
        OnDemandMovie,
        SignIn,
        VidoeComp,
        NVideo,
        MovieDetails,
    },
    config
)

export const AppSwitchNavigator = createAppContainer(SignUpStack)
