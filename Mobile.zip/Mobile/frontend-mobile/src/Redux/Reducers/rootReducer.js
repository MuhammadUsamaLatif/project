import { combineReducers } from "redux";
import authReducer from "./authReducers";
import errorReducer from "./errorReducers";
import productsReducer from './productsReducer';
import adminAuthReducer from './Admin/admin-Auth-Reducer';
import { addDemandMovie } from './uflix/OnDemandMovie/OnDemandMovie';
import { addComplaint } from "./uflix/complaint/complaint";
import { shareMovieReducer } from "./uflix/MoviesReducer";
import loadingReducer from './loadingReducer';
import {addFeedback} from './uflix/feedback/feedbackReducer'
export default combineReducers({
    auth: authReducer,
    errors: errorReducer,
    productsReducer,
    adminAuthReducer,
    shareMovieReducer,
    addDemandMovie,
    addComplaint,
    addFeedback,
    loadingReducer,
});