const initialState = {
    video: null
}
export const fetchVideo = (state = initialState, action) => {
    switch (action.type) {
        case 'FETCH_VIDEO':
            return { ...state, video: action.payload }
        default:
            return state
    }
}