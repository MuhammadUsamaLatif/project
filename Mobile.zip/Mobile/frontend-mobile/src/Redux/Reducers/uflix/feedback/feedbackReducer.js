import { ADD_FEEDBACK } from "../../../Actions/types";
const initialState = {
    message: ''
}
export const addFeedback = (state = initialState, action) => {
    switch (action.type) {
        case ADD_FEEDBACK:
            return { ...state, message: action.payload }
        default:
            return state
    }
}