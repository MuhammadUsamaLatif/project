import axios from "axios";
import setAuthToken from "../../utils/setAuthToken";
import { AsyncStorage } from 'react-native';
import jwt_decode from "jwt-decode";
import { baseURL } from "../../config/keys";
import {
    GET_ERRORS,
    SET_CURRENT_USER,
    USER_LOADING,
    SIGN_UP_USER,
    TOKEN
} from "./types";
// Register User
export const signUpUser = (userData, navigation) => dispatch => {
    dispatch({
        type: SIGN_UP_USER,
        payload: userData
    })
    navigation.navigate('PaymentDetails')
}

export const registerUser = (userData, navigation) => dispatch => {
    axios
        .post(`${baseURL}/api/users/register`, userData)
        .then(res => {
            console.log("Sign Up From client", res.data)
            navigation.navigate("SignIn") // re-direct to login on successful register
        })
        .catch(err => {
            console.log('Client error :', err.response)
            dispatch({
                type: GET_ERRORS,
                payload: err.response.data
            })
        });
};
// Login - get user token
export const loginUser = userData => dispatch => {
    axios
        .post(`${baseURL}/api/users/login`, userData)
        .then(res => {
            console.log('Client response :', res.data)
            // Save to localStorage
            // Set token to localStorage
            const { token, currentUser } = res.data;
            AsyncStorage.setItem("jwtToken", token);
            // Set token to Auth header
            setAuthToken(token);
            // Decode token to get user data
            const decoded = jwt_decode(token);
            // Set current user
            dispatch({
                type: SET_CURRENT_USER,
                payload: currentUser
            })
            dispatch(setCurrentUser(decoded));
        })
        .catch(err => {
            console.log(err.response.data)
            dispatch({
                type: GET_ERRORS,
                payload: err.response.data
            })
        });
};
// Set logged in user
export const setCurrentUser = decoded => {
    return {
        type: TOKEN,
        payload: decoded
    };
};
// User loading
export const setUserLoading = () => {
    return {
        type: USER_LOADING
    };
};
// Log user out
export const logoutUser = (navigation) => dispatch => {
    // Remove token from local storage
    AsyncStorage.removeItem("jwtToken");
    // Remove auth header for future requests
    setAuthToken(false);
    // Set current user to empty object {} which will set isAuthenticated to false
    dispatch(setCurrentUser({}));
    navigation.navigate('SignIn')
};