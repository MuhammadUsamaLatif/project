import axios from 'axios';
import { ADD_FEEDBACK, GET_ERRORS } from '../types';
import { baseURL } from '../../../config/keys';
export const addFeedback = (userData) => dispatch => {
    console.log("action user data", userData)    
    // const { _id } = userData
    const _id = '5d63d343d693c4001753f382'
    const url = `${baseURL}/api/users/add_feedback/${_id}`;
    axios.post(url, userData)
        .then(res => {
            console.log("Feedback", res.data)
            const { message } = res.data
            dispatch({
                type: ADD_FEEDBACK,
                payload: message
            })
        })
        .catch(err => {
            console.log('Client side on demand movie error :', err.response.data)
            dispatch({
                type: GET_ERRORS,
                payload: err.response.data
            })
        })
}