import axios from 'axios';
import { ADD_DEMAND_MOVIE, LOADING, GET_ERRORS } from '../types'
import { baseURL } from '../../../config/keys';
export const addDemandMovie = (userData) => dispatch => {
    const { _id } = userData
    const url = `${baseURL}/api/users/onDemand/${_id}`;
    axios.post(url, userData)
        .then(res => {
            console.log(res.data)
            dispatch({
                type: LOADING,
                payload: true
            })
            const { message } = res.data
            console.log('Redux message :', message)
            dispatch({
                type: ADD_DEMAND_MOVIE,
                payload: message
            })
            dispatch({
                type: LOADING,
                payload: false
            })
        })
        .catch(err => {
            console.log('Client side on demand movie error :', err.response.data)
            dispatch({
                type: GET_ERRORS,
                payload: err.response.data
            })
        }) 

}