import axios from 'axios';
import { ADD_COMPLAINT, GET_ERRORS } from '../types'
import { baseURL } from '../../../config/keys';
export const addComplaint = (userData) => dispatch => {
    const { _id } = userData
    const url = `${baseURL}/api/users/complaints/${_id}`;
    axios.post(url, userData)
        .then(res => {
            console.log('Complaint message :', res.data)
            const { message } = res.data
            dispatch({
                type: ADD_COMPLAINT,
                payload: message
            })
        })
        .catch(err => {
            console.log('Client side on demand movie error :', err.response.data)
            dispatch({
                type: GET_ERRORS,
                payload: err.response.data
            })
        })
}