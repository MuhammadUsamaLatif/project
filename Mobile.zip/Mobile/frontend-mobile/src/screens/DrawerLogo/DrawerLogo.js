import React from 'react'
import { Image, StyleSheet, View } from 'react-native'
import {Container, Header, Body, Content, } from 'native-base';
import icon from '../../../assets/images/icon.png';
import { DrawerItems } from 'react-navigation';
const CustomDrawerLogo = (props) => {
    return (
        <Container
        style={{
                backgroundColor: '#261010'
        }}
        >
    <Header
    style={styles.headerStyle}
    >
        <Body>
            <Image 
            style={ styles.imgStyle }
            source={icon}
            />
        </Body>
    </Header>
    <Content>
        <DrawerItems {...props} />
    </Content>
</Container>
    )
}
const styles = StyleSheet.create({
    imgStyle: {
        height: 120,
        width: 120
    },
    headerStyle: {
        height: 100,
        backgroundColor: '#261010'
    }
})

export default CustomDrawerLogo