import React, { Component } from 'react';
import { Text, StyleSheet, View, TouchableOpacity, TextInput, ScrollView, StatusBar, Platform } from 'react-native';
import { AntDesign, FontAwesome, Ionicons } from '@expo/vector-icons';
import { Container, Header, Title, Content, Button, Left, Right, Body, Icon, Form, Textarea } from 'native-base';
import { Font, AppLoading, Constants } from 'expo';
import { connect } from 'react-redux'
import { addFeedback } from '../../Redux/Actions/Feedback/Feedback';
import { Toaster } from '../Toaster/Toast';
import LoadingIndicator from '../LoadingIndicator/LoadingIndicator';
class Feedback extends Component {
    static navigationOptions = {
        drawerLabel: 'Feedback',
        drawerIcon: () => (
            <View>
                {Platform.OS === 'ios' ?
                    <Ionicons name='ios-thumbs-up' size={25} color="#5c4c4c" />
                    :
                    <FontAwesome name='thumbs-o-up' size={25} color="#5c4c4c" />
                }
            </View>
        ),
    };
    constructor(props) {
        super(props);
        this.state = {
            stars: [
                { name: 'staro', color: '#deb400' },
                { name: 'staro', color: '#deb400' },
                { name: 'staro', color: '#deb400' },
                { name: 'staro', color: '#deb400' },
                { name: 'staro', color: '#deb400' },
            ],
            fontLoaded: false,
            isLoadingComplete: false,
            title: '',
            review: '',
            showTost: false,
            isLoading: false

        }
    }
    componentDidMount() {
        StatusBar.setBarStyle('light-content', true)
        StatusBar.setBackgroundColor("#DF0100")
    }

    loadResourcesAsync = async () => {
        await Promise.all([
            Font.loadAsync({
                'avenirltstd-heavy': require('../../../assets/fonts/AvenirLTStd/AvenirLTStd-Book.otf'),
            }),
        ]);
    }

    handleLoadingError = () => {
        console.log('Some error occured during font load');
    }
    handleSubmit = () => {
        // const { _id } = this.props.currentUser
        const { title, review, } = this.state

        const userData = {
            title,
            review,
            ratings: 4
        }
        this.setState({ isLoading: true })
        this.props.dispatch(addFeedback(userData))
        setTimeout(() => {
            this.setState({ isLoading: false })
        }, 3000);
        setTimeout(() => {
            this.setState({ showTost: !this.state.showTost })
        }, 6000);
    }
    render() {
        const { message } = this.props
        const { isLoading } = this.state
        console.log('feedback component message :', message)
        const { title, review, showTost } = this.state
        if (this.state.isLoadingComplete) {
            return (
                <AppLoading
                    startAsync={this.loadResourcesAsync}
                    onError={this.handleLoadingError}
                    onFinish={() => this.setState({ isLoadingComplete: true })}
                />
            );
        } else if (isLoading) {
            return (
                <LoadingIndicator
                    title="Please wait...."
                />
            )
        }
        return (
            <Container style={{ backgroundColor: '#261010' }}>
                <Header style={{
                    backgroundColor: 'transparent', fontStyle: 'normal',
                }}>
                    <Left>
                        <Button transparent onPress={() => this.props.navigation.navigate('Home')}>
                            <Icon name="arrow-back" style={{ color: '#fff' }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title style={styles.TittleFeedBack}>Feedback</Title>
                    </Body>
                </Header>
                <Content>
                    <Toaster visible={showTost} message={message ? message : ''} />
                    <StatusBar barStyle="dark-content" backgroundColor="#DF0100" />
                    <View style={{ alignSelf: 'center', marginTop: 20 }}>
                        <FontAwesome name='thumbs-o-up' size={100} style={{ color: '#fff' }} />
                    </View>
                    <View style={styles.StartingView}>
                        {
                            this.state.stars.map((s, i) => {
                                return (
                                    <AntDesign key={i} name={s.name} style={{ color: s.color, fontSize: 50, }} />
                                )

                            })
                        }
                    </View>
                    <View style={{ alignSelf: 'center', marginTop: 10 }}>
                        <Text style={{ color: '#fff' }}>4 Stars</Text>
                    </View>
                    <View>
                        <TextInput
                            style={styles.textInput}
                            placeholder={'Title of your review'}
                            value={title}
                            onChangeText={title => this.setState({ title })}
                        />
                    </View>
                    <ScrollView style={{ marginTop: 7 }}>
                        <View>
                            <TextInput
                                style={styles.commentText}
                                placeholder={'Your review here....'}
                                value={review}
                                onChangeText={review => this.setState({ review })}
                            />
                        </View>
                    </ScrollView>
                    <TouchableOpacity
                        onPress={this.handleSubmit}
                    >
                        <View style={styles.ButtonTouchAbleOpacity}>
                            <Text style={{ color: '#fff', fontFamily: "avenirltstd-heavy" }}>POST YOUR REVIEW</Text>
                        </View>
                    </TouchableOpacity>
                </Content>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    FeedBackView: {
        marginTop: 120,
        alignSelf: 'center',
    },

    TextFeedBack:
    {
        fontWeight: 'bold',
        fontSize: 24,
        alignItems: 'center',
        marginRight: 50,
        marginLeft: 60,
        fontStyle: 'normal',
        fontFamily: 'avenirltstd-heavy',
        flexWrap: 'wrap',
    },
    commentText: {
        borderRadius: 5,
        borderWidth: 1,
        margin: 10,
        height: 120,
        backgroundColor: '#333333',
        color: '#fff',
        fontFamily: 'avenirltstd-heavy',
        paddingBottom: 75,
        paddingLeft: 10,
    },
    TittleFeedBack:
    {
        color: '#fff',
        paddingLeft: 12,
        fontStyle: 'normal',
        fontFamily: 'avenirltstd-heavy',
        fontWeight: 'bold',
        paddingLeft: 10
        // alignSelf: 'center',
    },

    StartingView: {
        marginTop: 30,
        flexDirection: 'row',
        justifyContent: 'center',

    },
    TextBox: {
        marginLeft: 15,
        marginRight: 15,
        borderColor: '#000000',
        borderWidth: 1,
        marginTop: 25,
    },
    TextArea:
    {
        paddingTop: 10,
        fontStyle: 'normal',
        fontFamily: 'avenirltstd-heavy',
        fontSize: 12,
        backgroundColor: '#333333',
    },
    ButtonTouchAbleOpacity: {
        marginTop: 40,
        backgroundColor: '#DF0100',
        marginLeft: 15,
        marginRight: 15,
        alignItems: 'center',
        justifyContent: 'center',
        height: 50
    },
    Done:
    {
        fontFamily: 'avenirltstd-heavy',
        fontSize: 15,
        fontStyle: 'normal',
        fontWeight: 'bold',
        color: '#fff'

    },
    textInput: {
        borderRadius: 5,
        borderWidth: 1,
        marginTop: 20,
        height: 50,
        backgroundColor: '#333333',
        marginLeft: 10,
        marginRight: 10,
        paddingLeft: 10,
        color: '#fff',
        fontFamily: 'avenirltstd-heavy'
    },
})

const mapStateToProps = (store) => {
    return {
        message: store.addFeedback.message,
        currentUser: store.auth.currentUser,
    }
}

export default connect(mapStateToProps)(Feedback)