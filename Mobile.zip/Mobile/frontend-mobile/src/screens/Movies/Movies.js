import React, { Component } from 'react';
import { AppLoading } from 'expo';
import { Text, View, Platform, ScrollView, Image, StyleSheet, TouchableHighlight, StatusBar } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import axios from 'axios';
import { baseURL } from '../../config/keys';
export default class Movies extends Component {
    static navigationOptions = {
        drawerLabel: 'Movies',
        drawerIcon: () => (
            <View>
                {Platform.OS === 'ios' ?
                    <Ionicons name='ios-move' size={25} color="#5c4c4c" />
                    :
                    <MaterialCommunityIcons name='movie-roll' size={25} color="#5c4c4c" />
                }
            </View>
        ),
    };

    constructor(props) {
        super(props);
        this.state = {
            isLoadingComplete: false,
            recommended: [],
            justAdded: []
        }
    }

    getVideo = () => {
        const url = `${baseURL}/api/movies/all_movies`;
        axios.get(url)
            .then(res => {
                const { movies } = res.data
                this.setState({ recommended: movies, justAdded: movies })
            })
            .catch(err => console.log('Error :', err))
    }
    componentDidMount() {
        // this.setState({isLoadingComplete: true})
        this.getVideo()
        StatusBar.setBarStyle('light-content', true);
        StatusBar.setBackgroundColor("#DF0100");
        // this.setState({isLoadingComplete: false})
    }
    loadResourcesAsync = async () => {
        await Promise.all([
            Font.loadAsync({
                'avenirltstd-heavy': require('../../../assets/fonts/AvenirLTStd/AvenirLTStd-Book.otf'),
            }),
        ]);
    }
    handleLoadingError = () => {
        console.log('Some error occured during font load');
    }
    render() {
        const { recommended, justAdded } = this.state
        if (this.state.isLoadingComplete) {
            return (
                <AppLoading
                    startAsync={this.loadResourcesAsync}
                    onError={this.handleLoadingError}
                    onFinish={() => this.setState({ isLoadingComplete: true })}
                />
            );
        }
        return (
            <View>
                <StatusBar barStyle="dark-content" backgroundColor="red" />
                <View style={{ margin: 5 }}>
                    <Text style={{ fontSize: 20, color: '#fff', margin: 10, fontFamily: 'avenirltstd-heavy' }}>
                        Recommended
                        </Text>
                </View>
                <View style={styles.moviesView}>
                    <ScrollView horizontal={true}>
                        {recommended.length >= 0 ? recommended.map((mov, index) => {
                            console.log(mov.image)
                            return (
                                <View style={styles.cardsView} key={index}>
                                    <TouchableHighlight
                                        onPress={() => this.props.movieDetailsHandler(mov)}>

                                        <Image source={{uri: `${baseURL}/${mov.image}`}} style={styles.cardImages}
                                        />
                                    </TouchableHighlight>
                                </View>
                            )
                        })
                            : <Text style={{color: '#fff', fontSize: 20 }}>There is no video in database</Text>
                        }
                    </ScrollView>
                </View>
                <View style={{ margin: 5 }}>
                    <Text style={{ color: '#fff', fontSize: 20, marginLeft: 13, fontFamily: 'avenirltstd-heavy' }}>Just Added</Text>
                </View>
                <View style={styles.moviesView}>
                    <ScrollView horizontal={true}>
                        {justAdded.length >=0 ? justAdded.map((mov, index) => {
                            return (
                                <View style={styles.cardsView} key={index} >
                                    <TouchableHighlight
                                        onPress={() => this.props.movieDetailsHandler(mov)}
                                    >
                                        <Image source={{uri: `${baseURL}/${mov.image}`}} style={styles.cardImages} />
                                    </TouchableHighlight>
                                </View>
                            )
                        })
                    : <Text style={{color: '#fff', fontSize: 20}}>There is no video in database</Text>
                    }
                    </ScrollView>
                </View>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    homeContainer: {
        backgroundColor: '#261010'
    },
    header: {
        backgroundColor: '#DF0100',
    },
    slider: {
        width: '100%',
        height: '30%'
    },
    moviesView: {
        margin: 7
    },
    cardsView: {
        margin: 10,
        borderRadius: 7,
        borderWidth: 2,
        flexDirection: 'row'
    },
    cardImages: {
        height: 250,
        width: 130
    }
})
