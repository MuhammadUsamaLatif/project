import React, { Component } from 'react'
import {
    Text, View, ImageBackground, StyleSheet,
    Image, TextInput, TouchableOpacity,
}
    from 'react-native'
import bgImage from '../../../assets/images/uflix/bg.png';
import icon from '../../../assets/images/SignUp/icon.png';
import { connect } from 'react-redux';
import { signUpUser } from '../../Redux/Actions/authActions';

class SignUp extends Component {
    state = {
        isLoadingComplete: false,
        name: '',
        email: '',
        password: '',
        confPassword: '',
        errorMessage: '',
        errorName: '',
        errorEmail: '',
        errorPassword: '',
        errorConfPassword: '',
        errorPasswordLength: '',
        errorPassworMatch: '',
        isUserAuthenticate: false,
        shakeText: false
    }

    loadResourcesAsync = async () => {
        await Promise.all([
            Font.loadAsync({
                'avenirltstd-heavy': require('../../../assets/fonts/AvenirLTStd/AvenirLTStd-Book.otf'),
            }),
        ]);
    }

    handleLoadingError = () => {
        console.log('Some error occured during font load');
    }

    submitHandler = () => {
        const { name, email, password, confPassword, } = this.state
        if ((name || email || password || confPassword).length <= 0) {
            return this.setState({
                errorName: 'Name field is required',
                errorEmail: 'Email field is required',
                errorPassword: 'password field is required',
                errorConfPassword: 'Confirm Password field is required'
            },
                () => {
                    setTimeout(() => {
                        this.setState({
                            errorName: '',
                            errorEmail: '',
                            errorPassword: '',
                            errorConfPassword: ''
                        })
                    }, 3000);
                }
            )
        }
        else if ((name || email).length <= 0) {
            return this.setState({
                errorName: 'Name field is required',
                errorEmail: 'Email field is required'
            }, () => {
                setTimeout(() => {
                    this.setState({ errorName: '', errorEmail: '' })
                }, 3000);
            })
        }
        else if (name.length <= 0) {
            return this.setState({
                errorName: 'Name field is required',
            }, () => {
                setTimeout(() => {
                    this.setState({ errorName: '' })
                }, 3000);
            })
        }
        else if (email.length <= 0) {
            return this.setState({
                errorEmail: 'Email field is required',
            }, () => {
                setTimeout(() => {
                    this.setState({ errorEmail: '' })
                }, 3000);
            })
        } else if (!email.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
            return this.setState({
                errorEmail: 'Invalid Email',
            }, () => {
                setTimeout(() => {
                    this.setState({ errorEmail: '' })
                }, 3000);
            })
        }
        else if ((password || confPassword).length <= 0) {
            return this.setState({
                errorConfPassword: 'Confirm Password field is required',
                errorPassword: 'password field is required',
            }, () => {
                setTimeout(() => {
                    this.setState({
                        errorConfPassword: '',
                        errorPassword: ''
                    })
                }, 3000);
            })
        }
        else if ((password || confPassword).length < 7) {
            return this.setState({ errorPasswordLength: 'password must be at least 7 characters' }, () => {
                setTimeout(() => {
                    this.setState({ errorPasswordLength: '' })
                }, 3000);
            })
        }
        else if (password !== confPassword) {
            return this.setState({ errorPassworMatch: 'Please enter same password' }, () => {
                setTimeout(() => {
                    this.setState({ errorPassworMatch: '' })
                }, 3000);
            })
        }
        else {
            this.setState({ isUserAuthenticate: true }, () => {
                const userData = {
                    name,
                    email,
                    password,
                    confPassword
                }
                this.props.dispatch(signUpUser(userData, this.props.navigation))
            })
        }

    }


    render() {
        const {
            name,
            email,
            password,
            confPassword,
            errorName,
            errorEmail,
            errorPassword,
            errorConfPassword,
            errorPasswordLength,
            errorPassworMatch
        } = this.state
        if (this.state.isLoadingComplete) {
            return (
                <AppLoading
                    startAsync={this.loadResourcesAsync}
                    onError={this.handleLoadingError}
                    onFinish={() => this.setState({ isLoadingComplete: true })}
                />
            );
        }
        return (
            <ImageBackground source={bgImage} style={styles.bgImage}>
                <View style={styles.viewContainer}>
                    <Image style={styles.image} source={icon} height={90} width={90} />
                    <View>

                        <Text style={styles.signUpText}>
                            Sign Up
                        </Text>
                    </View>
                    <View style={styles.viewFields}>
                        <View style={styles.eachInput}>
                            <TextInput
                                style={styles.textInput}
                                placeholder='Name'
                                value={name}
                                onChangeText={name => this.setState({ name, })}
                            />
                            {errorName ?
                                <Text style={styles.errorText}>{errorName}</Text>
                                :
                                null}
                        </View>
                        <View style={styles.eachInput}>
                            <TextInput
                                placeholder={'Email'}
                                style={styles.textInput}
                                value={email}
                                onChangeText={email => this.setState({ email })}
                            />
                            {errorEmail ?
                                <Text style={styles.errorText}>{errorEmail}</Text>
                                :
                                null}
                        </View>
                        <View style={styles.eachInput}>

                            <TextInput
                                style={styles.textInput}
                                placeholder={'Password'}
                                value={password}
                                onChangeText={password => this.setState({ password })}
                                secureTextEntry={true}
                            />
                            {(errorPassword || errorPasswordLength) ?
                                <Text style={styles.errorText}>{errorPassword || errorPasswordLength}</Text>
                                :
                                null}
                        </View>
                        <View style={styles.eachInput}>
                            <TextInput
                                style={styles.textInput}
                                placeholder={'Confirm Password'}
                                value={confPassword}
                                onChangeText={confPassword => this.setState({ confPassword })}
                                secureTextEntry={true}
                            />
                            {(errorConfPassword || errorPassworMatch || errorPasswordLength) ?
                                <Text style={styles.errorText}>{errorConfPassword || errorPassworMatch || errorPasswordLength}</Text>
                                :
                                null}
                        </View>

                        <TouchableOpacity
                            onPress={this.submitHandler}
                        >
                            <View style={styles.signUpBtn}>
                                <Text style={{ color: '#fff', fontSize: 20, fontFamily: 'avenirltstd-heavy' }}>
                                    Next
                                </Text>
                            </View>
                        </TouchableOpacity>
                        <View style={styles.lastText}>
                            <Text style={{ color: '#fff', fontFamily: 'avenirltstd-heavy', fontSize: 20 }}>
                                Already have account? <Text style={{ color: 'red', fontFamily: 'avenirltstd-heavy', fontSize: 20 }}
                                    onPress={() => this.props.navigation.navigate('SignIn')}

                                >Sign In</Text>
                            </Text>
                        </View>
                    </View>
                </View>

            </ImageBackground>
        )
    }
}


const styles = StyleSheet.create({
    bgImage: {
        flex: 1,
        height: 'auto',
        justifyContent: 'center',
        alignItems: 'center',
    },
    viewContainer: {
        opacity: 0.8,
        width: '95%',
        height: 'auto',
        backgroundColor: 'black',
        borderWidth: 2,
        borderRadius: 20,
    },
    image: {
        alignSelf: 'center',
    },
    signUpText: {
        color: '#fff',
        fontFamily: 'avenirltstd-heavy',
        fontWeight: 'bold',
        alignSelf: 'center',
        fontSize: 30,
        marginTop: 3,
        marginLeft: 10
    },
    viewFields: {
        marginTop: 15,
    },
    textInput: {
        borderRadius: 5,
        borderWidth: 1,
        marginTop: 10,
        height: 50,
        backgroundColor: '#333333',
        marginLeft: 10,
        marginRight: 10,
        paddingLeft: 10,
        color: '#fff',
        fontFamily: 'avenirltstd-heavy'
    },
    errorText: {
        color: '#DF0100',
        marginLeft: 10,
        marginTop: 5
    },
    signUpBtn: {
        marginTop: 25,
        marginLeft: 10,
        marginRight: 10,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#DF0100',
        height: 50,
        borderWidth: 1,
        borderRadius: 5
    },
    lastText: {
        marginTop: 30,
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom: 25,
        fontFamily: 'avenirltstd-heavy'
    },
})

const mapStateToProps = (store) => {
    return {
        data: store.auth
    }
}
export default connect(mapStateToProps)(SignUp)