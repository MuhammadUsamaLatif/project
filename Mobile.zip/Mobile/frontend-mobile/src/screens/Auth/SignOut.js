import React, { Component } from 'react';
import { Text, View, Platform, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { connect } from 'react-redux';
import { logoutUser } from '../../Redux/Actions/authActions';
class SignOut extends Component {
    static navigationOptions = {
        drawerLabel: 'SignOut',
        drawerIcon: () => (
            <View>
                {Platform.OS === 'ios' ?
                    <Ionicons name='ios-log-out' size={25} color="#5c4c4c" />
                    :
                    <Ionicons name='md-log-out' size={25} color="#5c4c4c" />
                }
            </View>
        ),
    };
    handleLogout = () => {
        this.props.dispatch(logoutUser(this.props.navigation))
    }
    render() {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <TouchableOpacity
                    onPress={ this.handleLogout  }
                >
                    <View style={styles.signOutBtn}>
                        <Text style={{ color: '#fff', fontSize: 20 }}> Sign Out </Text>
                    </View>
                </TouchableOpacity>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    signOutBtn: {
        marginTop: 35,
        marginLeft: 10,
        marginRight: 10,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'red',
        height: 50,
        borderWidth: 1,
        borderRadius: 5
    },

})

export default connect()(SignOut)