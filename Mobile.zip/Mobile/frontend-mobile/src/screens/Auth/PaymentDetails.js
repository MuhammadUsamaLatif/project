import React, { Component } from 'react'
import { Text, View, ImageBackground, StyleSheet, Image, TextInput, TouchableOpacity, } from 'react-native'
import { CheckBox } from 'react-native-elements';
import bgImage from '../../../assets/images/uflix/bg.png';
import icon from '../../../assets/images/SignUp/icon.png';
import america from '../../../assets/images/PaymentDetails/ic_american.png';
import mastercard from '../../../assets/images/PaymentDetails/ic_mastercard.png';
import visa from '../../../assets/images/PaymentDetails/ic_visa.png';
import { connect } from 'react-redux';
import { registerUser } from '../../Redux/Actions/authActions';
import LoadingIndicator from './../LoadingIndicator/LoadingIndicator';
class PaymentDetails extends Component {
    state = {
        checkBoxVal: false,
        fname: '',
        lname: '',
        cardNumber: '',
        cardExpirationDate: '',
        cardCVV: '',
        errorMessage: "",
        errors: {},
        isUserAuthenticate: false,
        isLoadingComplete: false,
        isLoading: false
    }

    loadResourcesAsync = async () => {
        await Promise.all([
            Font.loadAsync({
                'avenirltstd-heavy': require('../../../assets/fonts/AvenirLTStd/AvenirLTStd-Book.otf'),
                // 'AvenirLTStd-Medium': require('../../assets/fonts/AvenirLTStd/AvenirLTStd-Medium.otf'),
            }),
        ]);
    }

    handleLoadingError = () => {
        console.log('Some error occured during font load');
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.errors) {
            this.setState({
                errors: nextProps.errors
            });
        }
    }

    checkBoxHandler = () => {
        this.setState({
            checkBoxVal: !this.state.checkBoxVal,
            isUserAuthenticate: true
        })
    }

    submitHandler = () => {
        const { fname, lname, cardNumber, cardExpirationDate, cardCVV, checkBoxVal, } = this.state
        if (!checkBoxVal) {
            this.setState({ errorMessage: 'Please accept the terms and conditions by pressing check box' })
            setTimeout(() => {
                this.setState({ errorMessage: "" })
            }, 3000);
        }
        else {
            const { name, email, password, confPassword } = this.props.user
            var { apiLoading } = this.props
            console.log(apiLoading)

            const userData = {
                name,
                email,
                password,
                confPassword,
                fname,
                lname,
                cardNumber,
                cardExpirationDate,
                cardCVV
            }
            this.setState({ isUserAuthenticate: true, isLoading: true }, () => {
                this.props.dispatch(registerUser(userData, this.props.navigation))
                setTimeout(() => {
                    this.setState({ isLoading: false })
                }, 3000);
            })
        }

    }

    render() {
        const { apiLoading } = this.props
        console.log('api Loading: ', apiLoading)
        const { errors, errorMessage, isLoading } = this.state
        if (this.state.isLoadingComplete) {
            return (
                <View>
                    <AppLoading
                        startAsync={this.loadResourcesAsync}
                        onError={this.handleLoadingError}
                        onFinish={() => this.setState({ isLoadingComplete: true })}
                    />
                </View>
            );
        } else if (isLoading) {
            return (
                <LoadingIndicator 
                title="Please wait...."
                />
            )
        }
        return (
            <ImageBackground source={bgImage} style={styles.bgImage}>
                <View style={styles.viewContainer}>
                    {/* <View style={styles.viewIcon}> */}
                    <Image style={styles.image} source={icon} height={90} width={90} />
                    {/* </View> */}
                    <View>
                        <Text style={styles.paymentText}>
                            Payment Details
                        </Text>
                    </View>
                    <View style={styles.payments}>
                        <View style={styles.eachCard}>
                            <Image source={visa} style={styles.paymentStyles} />
                        </View>
                        <View style={styles.eachCard}>
                            <Image source={mastercard} style={{ height: 40, width: 60, borderRadius: 5 }} />
                        </View>
                        <View style={styles.eachCard}>
                            <Image source={america} style={{ height: 40, width: 60, borderRadius: 5 }} />
                        </View>
                    </View>
                    <View style={styles.viewFields}>
                        <View>
                            <TextInput
                                style={styles.textInput}
                                placeholder='First Name'
                                value={this.state.fname}
                                onChangeText={fname => this.setState({ fname })}
                            />
                            {
                                errors ?
                                    <Text style={styles.errorText}>{errors.fname}</Text> :
                                    null
                            }
                        </View>
                        <View>
                            <TextInput
                                placeholder={'Last Name'}
                                style={styles.textInput}
                                value={this.state.lname}
                                onChangeText={lname => this.setState({ lname })}
                            />
                            {errors ? <Text style={styles.errorText}>{errors.lname}</Text> : null}
                        </View>
                        <View>
                            <TextInput
                                style={styles.textInput}
                                placeholder={'Card Number'}
                                value={this.state.cardNum}
                                onChangeText={cardNumber => this.setState({ cardNumber })}
                            />
                            {errors ? <Text style={styles.errorText}>{errors.cardNumber}</Text> : null}
                        </View>
                        <View>

                            <TextInput
                                style={styles.textInput}
                                placeholder={'Expiration Date (MM/YY)'}
                                value={this.state.expire}
                                onChangeText={cardExpirationDate => this.setState({ cardExpirationDate })}
                            />
                            {errors ? <Text style={styles.errorText}>{errors.cardExpirationDate}</Text> : null}
                        </View>
                        <View>
                            <TextInput
                                style={styles.textInput}
                                placeholder={'Security Code (CVV)'}
                                value={this.state.securityCode}
                                onChangeText={cardCVV => this.setState({ cardCVV })}
                            />
                            {errors ? <Text style={styles.errorText}> {errors.cardCVV} </Text> : null}
                        </View>
                        {errorMessage ? <Text style={styles.errorText}> {errorMessage} </Text> : null}
                        <View style={styles.terms}>
                            <CheckBox
                                checked={this.state.checkBoxVal}
                                onPress={this.checkBoxHandler}
                                checkedColor='#DF0100'
                                containerStyle={{ margin: 0, padding: 0, }}
                            />
                            <Text style={{ color: '#fff', fontFamily: 'avenirltstd-heavy', fontSize: 13, marginTop: 5 }}>
                                I agree the terms <Text style={{ color: '#DF0100', fontFamily: 'avenirltstd-heavy', fontSize: 14 }}>term of use</Text> & <Text style={{ color: 'red', fontFamily: 'avenirltstd-heavy' }}>privacy statement</Text>
                            </Text>
                        </View>

                        <TouchableOpacity
                            onPress={this.submitHandler}
                        >
                            <View style={styles.signUpBtn}>
                                <Text style={{ color: '#fff', fontSize: 16, fontFamily: 'avenirltstd-heavy' }}>
                                    Complete Sign Up
                                </Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            </ImageBackground>
        )
    }
}

const styles = StyleSheet.create({
    bgImage: {
        flex: 1,
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        // width: Dimensions.get('window').width,
        // height: Dimensions.get('window').height,
    },
    viewContainer: {
        opacity: 0.8,
        width: '95%',
        height: 'auto',
        backgroundColor: 'black',
        borderWidth: 1,
        borderRadius: 10,
        margin: 15,
        paddingBottom: 17
    },
    image: {
        alignSelf: 'center',
        marginBottom: 5
    },
    paymentText: {
        color: '#fff',
        alignSelf: 'center',
        fontWeight: 'bold',
        fontSize: 30,
        marginTop: 3,
        marginLeft: 10,
        fontFamily: 'avenirltstd-heavy'
    },
    paymentStyles: {
        height: 40,
        width: 60,
        borderRadius: 2
    },
    eachCard: {
        margin: 4
    },
    viewFields: {
        marginTop: 1
    },
    textInput: {
        borderRadius: 5,
        borderWidth: 2,
        // marginTop: 4,
        height: 42,
        backgroundColor: '#333333',
        marginLeft: 10,
        marginRight: 10,
        paddingLeft: 10,
        color: '#fff'
    },
    signUpBtn: {
        marginTop: 10,
        marginLeft: 10,
        marginRight: 10,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#DF0100',
        height: 50,
        borderWidth: 1,
        borderRadius: 5
    },
    lastText: {
        marginTop: 30,
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom: 25,
        fontFamily: 'avenirltstd-heavy'
    },
    payments: {
        flexDirection: 'row',
        margin: 7
    },
    terms: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        margin: 3,
        flexWrap: 'nowrap'
    },
    errorText: {
        color: '#DF0100',
        margin: 5,
    },
})
const mapStateToProps = (state) => {
    return {
        user: state.auth.signUpUser,
        errors: state.errors,
        apiLoading: state.loadingReducer.isLoading
    }
}

export default connect(mapStateToProps)(PaymentDetails)