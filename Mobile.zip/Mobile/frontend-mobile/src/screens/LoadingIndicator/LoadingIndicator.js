import React, { Component } from 'react';
import { Animated, View, Text, StyleSheet, Easing, Modal } from 'react-native';
import logo from '../../../assets/images/icon_uflix.png'
class LoadingIndicator extends Component {
    state = {
        fadeAnim: new Animated.Value(0),
    }
    componentDidMount() {
        // First set up animation 
        Animated.timing(
            this.state.fadeAnim,
            {
                toValue: 5,
                duration: 3000,
                easing: Easing.linear,
                useNativeDriver: true
            }
        ).start()
    }
    render() {
        console.log('Logo component working')
        // Second interpolate beginning and end values (in this case 0 and 1)
        const { fadeAnim } = this.state
        const spin = fadeAnim.interpolate({
            inputRange: [0, 1],
            outputRange: ['0deg', '360deg']
        })
        return (
            <View style={styles.viewContainer}>
                <Animated.Image
                    style={[{ transform: [{ rotate: spin }] }, styles.animImage]}
                    source={logo} />
                <Text style={styles.waitText}>{this.props.title}</Text>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    viewContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent'
    },
    animImage: {
        height: 200,
        width: 200
    },
    waitText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 20
    }
})

export default LoadingIndicator
