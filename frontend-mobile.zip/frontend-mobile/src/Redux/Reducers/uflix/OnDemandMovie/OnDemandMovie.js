import { ADD_DEMAND_MOVIE } from '../../../Actions/types'

const initialState = {
    message: ''
}

export const addDemandMovie = (state = initialState, action) => {
    switch (action.type) {
        case ADD_DEMAND_MOVIE:
            return { ...state, message: action.payload }

        default:
            return state
    }
}