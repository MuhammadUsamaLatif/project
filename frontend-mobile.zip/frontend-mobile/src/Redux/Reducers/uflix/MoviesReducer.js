import { SHARE_Movie } from '../../Actions/types'

const initialState = {
    movie: {}
}

export const shareMovieReducer = (state = initialState, action) => {
    switch (action.type) {
        case SHARE_Movie:
        return { ...state, movie: action.payload }    
        
        default:
            return state
    }
}