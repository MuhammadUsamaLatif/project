const initialState = {
    message: null
}
export const addComplaint = (state = initialState, action) => {
    switch (action.type) {
        case 'ADD_COMPLAINT':
            return { ...state, message: action.payload }
        default:
            return state
    }
}