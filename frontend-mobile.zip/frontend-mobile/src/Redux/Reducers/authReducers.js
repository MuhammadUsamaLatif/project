//, EMAIL_VERIFICATION_TOKEN
import { SET_CURRENT_USER, USER_LOADING, SIGN_UP_USER, TOKEN } from "../Actions/types";
const isEmpty = require("is-empty");
const initialState = {
    isAuthenticated: false,
    user: {},
    currentUser: {},
    loading: false,
    signUpUser: {},
    emailSentMessage: ''
};
export default function (state = initialState, action) {
    switch (action.type) {
        case SET_CURRENT_USER:
            return {
                ...state,
                currentUser: action.payload
            };
        case TOKEN:
            return {
                ...state,
                isAuthenticated: !isEmpty(action.payload),
                user: action.payload
            };
        case USER_LOADING:
            return {
                ...state,
                loading: true
            };
        case SIGN_UP_USER:
            return {
                ...state,
                signUpUser: action.payload
            }
        default:
            return state;
    }
}