import { SHARE_Movie } from '../types';

export const shareMovie = (movie, navigation) => dispatch => {
    dispatch({
        type: SHARE_Movie,
        payload: movie
    })
    navigation.navigate('VidoeComp')
}