import React, { Component } from 'react';
import { View, Text, Platform, StyleSheet, Image, Dimensions, ScrollView } from 'react-native';
import { Container, Header, Body, Content, Title, Left, Button } from 'native-base';
import { Ionicons, } from '@expo/vector-icons';
import { connect } from 'react-redux';
import VidoeComp from '../Videos/Video';

class MovieDetails extends Component {
  state = {
    mayAlsoLike: [
      { mov: require('../../../assets/images/uflix/mov_4.jpg') },
      { mov: require('../../../assets/images/uflix/mov_5.jpg') },
      { mov: require('../../../assets/images/uflix/mov_6.jpg') }
    ],
    movies: [],
    isLoading: true
  }
  render() {
    return (
      <Container
        style={styles.homeContainer}
      >
        <Header
          style={styles.header}
        >
          <Left>
            <Button transparent
              onPress={() => this.props.navigation.navigate('Home')}
            >
              {Platform.OS === 'ios' ? <Ionicons name="ios-arrow-back" size={32} style={{ color: '#fff' }} /> :
                <Ionicons name="md-arrow-back" size={32} style={{ color: '#fff' }} />
              }
            </Button>
          </Left>
          <Body style={{ marginLeft: 20 }}>
            <Title style={{ marginLeft: 10 }}>Hobbs & Shaw</Title>
          </Body>
        </Header>
        <Content>
          <View style={styles.firstView}>
          </View>
          <ScrollView>
            <View style={styles.movieTitle}>
              <Text style={styles.boldText} onPress={this.getVideo}>Hobbs & Shaw</Text>
              <Text style={{ color: '#fff' }}>Duration: 2h 16m</Text>
            </View>
            <View style={{ margin: 7, borderBottomColor: '#DF0100', borderWidth: 3 }} />
            <View style={{ margin: 7 }}>
              <Text style={{ color: '#fff' }}>
                Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                when an unknown printer took a galley of type and scrambled it to make a type specimen book.
              </Text>
            </View>
            <View style={{ marginTop: 25, margin: 5 }}>
              <Text style={{ color: '#fff', fontSize: 25 }}>You may also like</Text>
            </View>
            {/* Movies List */}
            <View style={styles.moviesView}>
              <ScrollView horizontal={true}>
                {this.state.mayAlsoLike.map((img, index) => {
                  return (
                    <View style={styles.cardsView} key={index}>
                      <Image source={img.mov} style={styles.cardImages}
                      />
                    </View>
                  )
                })}
              </ScrollView>
            </View>
          </ScrollView>
        </Content>
      </Container>
    );
  }
}

const mapStateToProps = (store) => {
  return {
    image: store.shareImageReducer.image
  }
}

const styles = StyleSheet.create({
  homeContainer: {
    backgroundColor: '#261010'
  },
  header: {
    backgroundColor: 'transparent',
  },
  firstView: {
    margin: 1,
    width: '100%',
    height: 'auto'
  },
  moviewImage: {
    width: '100%',
    height: 180,
    margin: 5,
  },
  movieTitle: {
    margin: 5,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  boldText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#fff'
  },
  moviesView: {
    margin: 7
  },
  cardsView: {
    margin: 10,
    borderRadius: 7,
    borderWidth: 2,
    flexDirection: 'row'
  },
  cardImages: {
    height: 250,
    width: 130
  },
  landscapeVideoContainer: {
    flex: 1,
    height: '100%',
    width: '100%',
  },
  portraitVideoContainer: {
    width: Dimensions.get('window').width,
    height: 250
  },
})

export default connect(mapStateToProps)(MovieDetails) 