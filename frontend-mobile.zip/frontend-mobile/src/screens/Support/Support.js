import React, { Component } from 'react';
import { Text, View, Platform, StyleSheet } from 'react-native';
import { SimpleLineIcons, Ionicons } from '@expo/vector-icons';
import { Container, Header, Left, Body, Content, Button, Title } from 'native-base';

export default class Support extends Component {
    static navigationOptions = {
        drawerLabel: 'Support',
        drawerIcon: () => (
            <View>
                {Platform.OS === 'ios' ?
                    <SimpleLineIcons name='support' size={25} color="#5c4c4c" />
                    :
                    <SimpleLineIcons name='support' size={25} color="#5c4c4c" />
                }
            </View>
        ),
    };
    render() {
        return (
            <Container
                style={styles.homeContainer}
            >
                <Header
                    style={styles.header}
                >
                    <Left>
                        <Button transparent
                            onPress={() => this.props.navigation.navigate('Home')}
                        >
                            {Platform.OS === 'ios' ? <Ionicons name="ios-arrow-back" size={32} style={{ color: '#fff' }} /> :
                                <Ionicons name="md-arrow-back" size={32} style={{ color: '#fff' }} />
                            }
                        </Button>
                    </Left>
                    <Body style={{ marginLeft: 40, }}>
                        <Title style={{marginLeft: 22}}>Support</Title>
                    </Body>
                </Header>
                <Content style={{ flex: 1, }}>
                    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>

                        <Text style={{ color: '#fff', fontSize: 40, fontWeight: 'bold' }}> Support Screen </Text>
                    </View>
                </Content>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    homeContainer: {
        backgroundColor: '#261010'
    },
    header: {
        backgroundColor: 'transparent',
    },
})