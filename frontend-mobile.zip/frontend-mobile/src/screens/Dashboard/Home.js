import React, { Component } from 'react';
import { View, StyleSheet, Platform, StatusBar, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons'
import { Container, Header, Title, Content, Button, Left, Right, Body, } from 'native-base';
import CustomCrousel from '../Crousel/Crousel';
import Movies from '../Movies/Movies';
import { connect } from 'react-redux';
import { shareMovie } from '../../Redux/Actions/Uflix/MovieShareAction';
class Home extends Component {
    state = {
        searchField: false,
        isImageRecieved: false,
    }
    static navigationOptions = {
        drawerLabel: 'Home',
        drawerIcon: () => (
            <View>
                {Platform.OS === 'ios' ?
                    <Ionicons name='ios-home' size={32} color="#5c4c4c"  />
                    :
                    <Ionicons name='md-home' size={32} color="#5c4c4c" />
                }
            </View>
        ),
    };
    componentDidMount() {
        StatusBar.setBarStyle('light-content', true)
        StatusBar.setBackgroundColor('#DF0100')
    }

    movieDetailsHandler = (mov) => {
        this.props.dispatch(shareMovie(mov, this.props.navigation))
    }

    render() {
        return (
            <Container
                style={styles.homeContainer}        
            >
                <Header
                    style={styles.header}
                >
                    <Left>
                        <Button transparent
                            onPress={() => this.props.navigation.toggleDrawer()}
                        >
                            {Platform.OS === 'ios' ? <Ionicons name="ios-menu" size={32} style={{ color: '#fff' }} /> : <Ionicons name="md-menu" size={32} style={{ color: '#fff' }} />}
                        </Button>
                    </Left>
                    <Body style={{ marginLeft: 50, width: '100%'}} >
                        <Title style={{ alignSelf: 'center', marginLeft: 30 }}
                        >Home</Title>
                    </Body>
                    <Right>
                        {Platform.OS === 'ios' ? <Ionicons name="ios-search" size={32} style={{ color: '#fff' }} /> : <Ionicons name="md-search" size={32} style={{ color: '#fff' }} />}
                    </Right>
                </Header>
                <Content>
                    {/* Crousel section */}
                    <View>
                        <StatusBar barStyle="dark-content" backgroundColor="#DF0100" />
                        <CustomCrousel
                        />
                    </View>
                    <Movies
                        movieDetailsHandler={this.movieDetailsHandler}
                    />
                </Content>
            </Container>
        );
    }
}
const styles = StyleSheet.create({
    homeContainer: {
        backgroundColor: '#261010'
    },
    header: {
        backgroundColor: 'transparent',
    },
    slider: {
        width: '100%',
        height: '30%'
    },
    moviesView: {
        margin: 7
    },
    cardsView: {
        margin: 10,
        borderRadius: 7,
        borderWidth: 2,
        flexDirection: 'row'
    },
    cardImages: {
        height: 250,
        width: 130
    }
})
// const mapStateToProps = (store) => {
//     return {
//         image: store.shareImageReducer.image
//     }
// }
export default connect()(Home)  