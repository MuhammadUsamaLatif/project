import React from 'react';
import { ScreenOrientation } from 'expo';
import { StyleSheet, Dimensions, Text, View, } from 'react-native';
import { Container, Header, Content, Left, Body, Icon, Button } from 'native-base';
import { Video } from 'expo-av';
// import VideoPlayer from 'expo-video-player'
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import { connect } from 'react-redux';
import { baseURL } from '../../config/keys';
class VidoeComp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            viewMode: Dimensions.get("window").height > 500 ? "portrait" : "landscape",
            shouldPlay: true,
            rate: 1.0,
            volume: 1.0,
            isMuted: false,
            resizeMode: 'cover',
            isLooping: true,
            useNativeControls: true,
            playPause: false,
            expoIconsSize: 20,
            didJustFinish: false,
            isBuffering: false,
            isLoaded: true,
            isPlaying: true,
            durationMillis: '',
            playableDurationMillis: '',
            positionMillis: '',
            progressUpdateIntervalMillis: '',
            sliderMillis: 1,
            showController: false,
            videoFile: '',
            movies: [],
        }
        Dimensions.addEventListener("change", this.updateStyles);
    }

    landscapOrientationHandler = () => {
        ScreenOrientation.lockAsync(ScreenOrientation.Orientation.LANDSCAPE)
    }
    portraiteOrientationHandler = () => {
        ScreenOrientation.lockAsync(ScreenOrientation.Orientation.PORTRAIT)
    }
    updateStyles = (dims) => {
        this.setState({
            viewMode:
                dims.window.height > 500 ? "portrait" : "landscape"
        });
    }
    componentWillUnmount() {
        Dimensions.removeEventListener("change", this.updateStyles);
    }
    render() {
        const {
            shouldPlay, useNativeControls, rate, volume, resizeMode, viewMode, isPlaying, videoFile,
            isLooping,
        } = this.state
        const { singleMovie } = this.props
        return (
            <Container style={{ backgroundColor: '#261010' }}>
                <Header style={{
                    backgroundColor: 'transparent', fontStyle: 'normal',
                }}>
                    <Left>
                        <Button transparent onPress={() => this.props.navigation.navigate('Home')}>
                            <Icon name="arrow-back" style={{ color: '#fff' }} />
                        </Button>
                    </Left>
                    <Body />
                </Header>
                <Content>
                    <View style={{ width: '100%', }}>
                        <TouchableWithoutFeedback>
                            <Video
                                source={{ uri: `${baseURL}/${singleMovie.movie.video}` }}
                                rate={1.0}
                                volume={1.0}
                                isMuted={false}
                                resizeMode="cover"
                                shouldPlay
                                isLooping
                                style={{ width: '100%', height: 300 }}
                                useNativeControls
                            />
                            {/* <VideoPlayer
                                videoProps={{
                                    source:  `${baseURL}/${singleMovie.video}`,
                                    shouldPlay: true,
                                    resizeMode: Video.RESIZE_MODE_COVER,
                                    useNativeControls,
                                    rate,
                                }}
                                style={[viewMode === 'portrait' ? styles.portraitVideoContainer : styles.landscapeVideoContainer, { position: 'relative' }]}
                                isLooping={isLooping}
                                isPortrait={true}
                                volume={volume}
                                isPlaying={isPlaying}
                            /> */}
                        </TouchableWithoutFeedback>
                    </View>
                    <View style={styles.movieTitle}>

                        <View style={styles.descView}>
                            <Text style={styles.boldText}>Title -> </Text>
                            <Text style={styles.nestedText}>{singleMovie.movie.title}</Text>
                        </View>
                        <View style={styles.descView}>

                            <Text style={styles.boldText}>Language -> </Text>
                            <Text style={styles.nestedText}> {singleMovie.movie.language}</Text>
                        </View>
                        <View style={styles.descView}>

                            <Text style={styles.boldText}>Genre -> </Text>
                            <Text style={styles.nestedText}>{singleMovie.movie.genre}</Text>
                        </View>
                        <View style={styles.descView}>

                            <Text style={styles.boldText}>Cast -> </Text>
                            <Text style={styles.nestedText}> {singleMovie.movie.cast} </Text>
                        </View>
                        <View>
                            <Text style={styles.boldText}>Description -> </Text>
                            <Text style={styles.nestedText}> {singleMovie.movie.description} </Text>
                        </View>

                    </View>
                </Content>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#261010',
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        height: '100%'
    },
    descView: {
        flexDirection: 'row',
        // justifyContent: 'space-around'
    },
    boldText: {
        fontSize: 20,
        fontWeight: 'bold',
        color: 'red'
    },
    nestedText: {
        color: '#fff',
        fontSize: 15
    },
    movieTitle: {
        margin: 5,
        // flexDirection: 'row',
        // justifyContent: 'space-between'
    },
    posterStyle: {
        width: '100%',
        height: '100%'
    },
    controllerContainer: {
        justifyContent: 'flex-end',
        alignItems: 'center',
        width: '100%',
        height: 5
    },
    controllerIconsContainer: {
        width: '100%',
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        margin: 10,
        position: 'absolute',
    },
    landscapeVideoContainer: {
        flex: 1,
        height: '100%',
        width: '100%',
    },
    portraitVideoContainer: {
        width: Dimensions.get('window').width,
        height: 250
    },
    playPauseForwardPreviousView: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        margin: 10
    },
    durationView: {
        flexDirection: 'row',
        justifyContent: 'space-around'
    },
    durationText: {
        color: '#fff'
    }
});
const mapStateToProps = (store) => {
    return {
        singleMovie: store.shareMovieReducer
    }
}
export default connect(mapStateToProps)(VidoeComp)