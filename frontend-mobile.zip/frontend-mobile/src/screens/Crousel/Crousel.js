import React from 'react';
import { StyleSheet, Text, Image, View, SafeAreaView, Dimensions } from 'react-native';
import Carousel, { Pagination } from 'react-native-snap-carousel';
export default class CustomCrousel extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            activeSlide: 0,
            carouselItems: [
                {
                    slider: require('../../../assets/images/uflix/slider.png'),
                },
                {
                    slider: require('../../../assets/images/uflix/latest-news-s-3.jpg') ,

                },
                {
                    slider: require('../../../assets/images/uflix/related-movie-s-1.jpg'),                    
                },
            ]
        }
    }
    // componentDidMount() {
    //     this.automaticSlidesHandler()
    // }
    

    _renderItem({ item, index }) {
        return (
            <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row' }}>
                <Image source={item.slider} style={{ height: 250, width: '100%' }} 
                />
            </View>
        )
    }

    get pagination() {
        const { carouselItems, activeSlide } = this.state;
        return (
            <Pagination
                dotsLength={carouselItems.length}
                activeDotIndex={activeSlide}
                containerStyle={{ backgroundColor: 'transparent', marginTop: 200 }}
                dotStyle={{
                    width: 12,
                    height: 12,
                    borderRadius: 5,
                    marginHorizontal: 6,
                    backgroundColor: 'red'
                }}
                inactiveDotStyle={{
                    width: 13,
                    height: 13,
                    backgroundColor: '#333333'
                }}
                inactiveDotOpacity={0.8}
                inactiveDotScale={0.8}
            />
        );
    }
    onSnapToItemHandler = (index) => {
        this.setState({ activeSlide: index })
    }
    render() {
        return (
            <SafeAreaView style={styles.container}>
                <View>
                    <Carousel
                        ref={ref => this.carousel = ref}
                        data={this.state.carouselItems}
                        sliderWidth={Dimensions.get('window').width}
                        itemWidth={Dimensions.get('window').width}
                        renderItem={this._renderItem}
                        onSnapToItem={index => this.onSnapToItemHandler(index) }
                    >
                    </Carousel>
                </View>
                <View style={{ position: 'absolute' }}>
                    {this.pagination}
                </View>
            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        height: 250,
        width: '100%',
        backgroundColor: '#131420',
        alignItems: 'center',
        justifyContent: 'center',
    },
});
