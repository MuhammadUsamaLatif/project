import React, { Component } from 'react';
import { AppLoading } from 'expo';
import { Text, View, ImageBackground, StyleSheet, Image, TextInput, TouchableOpacity, StatusBar, AsyncStorage } from 'react-native'
import bgImage from '../../../assets/images/uflix/bg.png';
import icon from '../../../assets/images/SignUp/icon.png';
import { connect } from 'react-redux';
import { loginUser } from '../../Redux/Actions/authActions';
import LoadingIndicator from './../LoadingIndicator/LoadingIndicator';

class SignIn extends Component {
    state = {
        email: '',
        password: '',
        isUserAuthenticate: false,
        isLoadingComplete: false,
        errors: {},
        isLoading: false
    }
    componentWillMount() {
        if (this.props.auth.isAuthenticated) {
            this.props.navigation.navigate('Home')
        }
    }
    componentDidMount() {
        StatusBar.setBarStyle('light-content', true)
        StatusBar.setBackgroundColor("#DF0100")
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.auth.isAuthenticated) {
            this.props.navigation.navigate('Home'); // push user to dashboard when they login
        }
        if (nextProps.errors) {
            this.setState({
                errors: nextProps.errors
            });
        }
    }
    loadResourcesAsync = async () => {
        await Promise.all([
            Font.loadAsync({
                'avenirltstd-heavy': require('../../../assets/fonts/AvenirLTStd/AvenirLTStd-Book.otf'),
            }),
        ]);
    }

    handleLoadingError = () => {
        console.log('Some error occured during font load');
    }
    loginHandler = () => {
        const { email, password } = this.state
        const userData = {
            email,
            password
        }
        this.setState({ isLoading: true })
        this.props.dispatch(loginUser(userData))
        setTimeout(() => {
            this.setState({ isLoading: false })
        }, 4000);
    }
    render() {

        console.log(this.props.auth.isAuthenticated)
        const { errors, isLoading } = this.state
        if (this.state.isLoadingComplete) {
            return (
                <AppLoading
                    startAsync={this.loadResourcesAsync}
                    onError={this.handleLoadingError}
                    onFinish={() => this.setState({ isLoadingComplete: true })}>
                </AppLoading>
            );
        } else if (isLoading) {
            return (
                <LoadingIndicator 
                title="please wait....."
                />
            )
        }
        return (
            <ImageBackground source={bgImage} style={styles.bgImage}>
                <View style={styles.viewContainer}>
                    {/* <View style={styles.viewIcon}> */}
                    <Image style={styles.image} source={icon} height={90} width={90} />
                    {/* </View> */}
                    <View>
                        <Text style={styles.signInText}>
                            Sign In
                        </Text>
                    </View>
                    <View style={styles.viewFields}>

                        <View style={styles.eachInput}>
                            <TextInput
                                placeholder={'Email'}
                                style={styles.textInput}
                                value={this.state.email}
                                onChangeText={email => this.setState({ email })}
                            />
                            {errors ? <Text style={styles.errorText}>{errors.email || errors.emailNotFound}</Text> : null}
                        </View>
                        <View style={styles.eachInput}>

                            <TextInput
                                style={styles.textInput}
                                placeholder={'Password'}
                                value={this.state.password}
                                onChangeText={password => this.setState({ password })}
                                secureTextEntry={true}
                            />
                            {errors ? <Text style={styles.errorText}>{errors.password || errors.passwordIncorrect}</Text> : null}
                        </View>

                        <TouchableOpacity
                            onPress={this.loginHandler}
                        >
                            <View style={styles.signInBtn}>
                                <Text style={{ color: '#fff', fontSize: 20, fontFamily: "avenirltstd-heavy" }}>
                                    Sign In
                                </Text>
                            </View>
                        </TouchableOpacity>
                        <View style={styles.lastText}>
                            <Text style={{ color: '#fff', fontFamily: 'avenirltstd-heavy', fontSize: 20 }}>
                                Dont have an account? <Text style={{ color: 'red', fontSize: 20 }}
                                    onPress={() => this.props.navigation.navigate('SignUp')}
                                >Sign Up</Text>
                            </Text>
                        </View>
                    </View>
                </View>
            </ImageBackground>
        )
    }
}

const styles = StyleSheet.create({
    bgImage: {
        flex: 1,
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        alignItems: 'center',
        // width: Dimensions.get('window').width,
        // height: Dimensions.get('window').height,
    },
    viewContainer: {
        opacity: 0.8,
        width: '95%',
        height: 'auto',
        backgroundColor: 'black',
        borderWidth: 2,
        borderRadius: 20,

    },
    image: {
        alignSelf: 'center',
    },
    signInText: {
        alignSelf: 'center',
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 30,
        marginTop: 40,
        marginLeft: 10,
        fontFamily: 'avenirltstd-heavy'
    },
    viewFields: {
        marginTop: 15,
    },
    textInput: {
        borderRadius: 5,
        borderWidth: 1,
        marginTop: 10,
        height: 45,
        backgroundColor: '#333333',
        marginLeft: 10,
        marginRight: 10,
        paddingLeft: 10,
        color: '#fff'
    },
    signInBtn: {
        marginTop: 35,
        marginLeft: 10,
        marginRight: 10,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#DF0100',
        height: 50,
        borderWidth: 1,
        borderRadius: 5
    },
    lastText: {
        marginTop: 50,
        paddingBottom: 20,
        justifyContent: 'center',
        alignItems: 'center',
        paddingBottom: 40
    },
    errorText: {
        color: '#DF0100',
        marginLeft: 10,
        marginTop: 5
    },
})
const mapStateToProps = state => ({
    auth: state.auth,
    errors: state.errors,
});

export default connect(mapStateToProps)(SignIn)