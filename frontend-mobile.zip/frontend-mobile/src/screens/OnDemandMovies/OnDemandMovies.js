import React, { Component } from 'react';
import { Image, View, Platform, StyleSheet, StatusBar, TextInput,TouchableOpacity, Text, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Container, Header, Left, Body, Content, Button, Title, Right, } from 'native-base';
import { connect } from 'react-redux';
import { addDemandMovie } from '../../Redux/Actions/OnDemandMovie/OnDmandMovie';
import LoadingIndicator from '../LoadingIndicator/LoadingIndicator';
import { Toaster } from '../Toaster/Toast';

class OnDemandMovie extends Component {
    state = {
        fname: '',
        lname: '',
        email: '',
        title1: '',
        title2: '',
        title3: '',
        review: '',
        messageShow: false,
        showTost: false,
        isLoading: false
    }
    static navigationOptions = {
        drawerLabel: 'On Demand Movie',
        drawerIcon: () => (
            <View>
                {Platform.OS === 'ios' ?
                    <Ionicons name='ios-videocam' size={25} color="#5c4c4c" />
                    :
                    <Ionicons name='md-videocam' size={25} color="#5c4c4c" />
                }
            </View>
        ),
    };
    componentDidMount() {
        StatusBar.setBarStyle('light-content', true)
        StatusBar.setBackgroundColor("#DF0100")

    }
    handleSubmit = () => {
        const { email, _id } = this.props.currentUser
        const { title1, title2, title3, review } = this.state
        var { apiLoading } = this.props
        const userData = {
            _id,
            email,
            title1,
            title2,
            title3,
            review
        }
        this.setState({ isLoading: true })
        this.props.dispatch(addDemandMovie(userData))
        setTimeout(() => {
            this.setState({ isLoading: false })
        }, 3000);
        setTimeout(() => {
            this.setState({ showTost: !this.state.showTost })
        }, 6000);
    }

    render() {
        const { email, fname, lname } = this.props.currentUser
        const { message, apiLoading } = this.props
        const { title1, title2, title3, review, showTost, isLoading } = this.state
        console.log('_id :',this.props.currentUser._id)
        if (isLoading) {
            return (
                <LoadingIndicator
                    title="Please wait...."
                />
            )
        }

        return (
            <Container
                style={styles.complaintContainer}
            >
                <Header
                    style={styles.complaintHeader}
                >
                    <Left>
                        <Button transparent
                            onPress={() => this.props.navigation.navigate('Home')}
                        >
                            {Platform.OS === 'ios' ? <Ionicons name="ios-arrow-back" size={32} style={{ color: '#fff' }} /> :
                                <Ionicons name="md-arrow-back" size={32} style={{ color: '#fff' }} />
                            }
                        </Button>
                    </Left>
                    <Body>
                        <Title style={{ alignSelf: 'center' }}>On Demand Movie</Title>
                    </Body>
                    <Right />
                </Header>
                <Content style={styles.complaintContent}>
                    <Toaster visible={showTost} message={message ? message : ''} />
                    {/* {this.props.message ? alert(this.props.message) : null}                     */}
                    <StatusBar barStyle="dark-content" backgroundColor="#DF0100" />
                    <View style={{ margin: 13 }}>
                        <Text style={{ color: '#fff', fontFamily: 'avenirltstd-heavy', alignSelf: 'center', paddingLeft: 10, paddingRight: 10, flexWrap: 'nowrap', fontSize: 12 }}>Want to watch your favourite TV Show or Movie on demand?</Text>
                        <Text style={{ color: '#fff', fontFamily: 'avenirltstd-heavy', marginLeft: 20, marginRight: 20, fontSize: 12, marginTop: 3, alignSelf: 'center' }}>Please send us Request</Text>
                    </View>
                    <View style={styles.viewFields}>
                        <View>
                            <TextInput
                                style={styles.textInput}
                                placeholder='First Name'
                                value={fname}
                                onChangeText={fname => this.setState({ fname, })}
                            />
                        </View>
                        <View>
                            <TextInput
                                style={styles.textInput}
                                placeholder='Last Name'
                                value={lname}
                                onChangeText={lname => this.setState({ lname, })}
                            />
                        </View>
                        <View>
                            <TextInput
                                placeholder={'Email'}
                                style={styles.textInput}
                                value={email}
                                onChangeText={email => this.setState({ email })}
                            />

                        </View>
                        <View>

                            <TextInput
                                style={styles.textInput}
                                placeholder={'Title Suggestion 1'}
                                value={title1}
                                onChangeText={title1 => this.setState({ title1 })}
                            />
                        </View>
                        <View>
                            <TextInput
                                style={styles.textInput}
                                placeholder={'Title Suggestion 2'}
                                value={title2}
                                onChangeText={title2 => this.setState({ title2 })}
                            />
                        </View>
                        <View>
                            <TextInput
                                style={styles.textInput}
                                placeholder={'Title Suggestion 3'}
                                value={title3}
                                onChangeText={title3 => this.setState({ title3 })}
                            />
                        </View>
                        <ScrollView style={{ marginTop: 7 }}>
                            <View>
                                <TextInput
                                    style={styles.commentText}
                                    placeholder={'Your review here....'}
                                    value={review}
                                    onChangeText={review => this.setState({ review })}
                                />
                            </View>
                        </ScrollView>

                        <TouchableOpacity
                            onPress={this.handleSubmit}
                        >
                            <View style={styles.signUpBtn}>
                                <Text style={{ color: '#fff', fontSize: 20, fontFamily: 'avenirltstd-heavy' }}>
                                    SUBMIT REQUEST
                                </Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    {/* <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                        {
                            messageShow ? <span style={{ color: 'red', fontWeight: 'bold', alignSelf: 'center', textAlign: 'center' }}>{message ? message : ''}</span> : ''
                        }
                    </div> */}
                </Content>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    complaintContainer: {
        backgroundColor: '#261010'
    },
    complaintHeader: {
        backgroundColor: 'transparent',
    },
    complaintContent: {
        flex: 1,
    },
    logoView: {
        alignSelf: 'center',
        marginTop: 15
    },
    logoStyle: {
        height: 90,
        width: 90
    },
    viewFields: {
        marginTop: 8,
    },
    textInput: {
        borderRadius: 5,
        borderWidth: 1,
        marginTop: 10,
        height: 40,
        backgroundColor: '#333333',
        marginLeft: 10,
        marginRight: 10,
        paddingLeft: 10,
        color: '#fff',
        fontFamily: 'avenirltstd-heavy'
    },
    signUpBtn: {
        marginTop: 13,
        marginLeft: 10,
        marginRight: 10,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#DF0100',
        height: 50,
        borderWidth: 1,
        borderRadius: 5
    },
    commentText: {
        borderRadius: 5,
        borderWidth: 1,
        margin: 10,
        height: 100,
        backgroundColor: '#333333',
        color: '#fff',
        fontFamily: 'avenirltstd-heavy',
        paddingBottom: 52,
        paddingLeft: 10,
    }
})
const mapStateToProps = (state) => {
    return {
        user: state.auth.user,
        currentUser: state.auth.currentUser,
        isAuthenticated: state.auth.isAuthenticated,
        message: state.addDemandMovie.message,
        apiLoading: state.loadingReducer.isLoading
    }
}
export default connect(mapStateToProps)(OnDemandMovie)