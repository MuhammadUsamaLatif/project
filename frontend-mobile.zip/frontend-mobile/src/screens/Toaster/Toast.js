import { ToastAndroid, } from 'react-native';
export const Toaster = (props) => {
    if (props.visible) {
        ToastAndroid.showWithGravityAndOffset(
            props.message,
            ToastAndroid.LONG,
            ToastAndroid.BOTTOM,
            25,
            100,
        );
        return null;
    }
    return null;
};
