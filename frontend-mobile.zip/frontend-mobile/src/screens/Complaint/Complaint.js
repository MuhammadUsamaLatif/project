import React, { Component } from 'react';
import { Image, View, Platform, StyleSheet, StatusBar, TextInput, TouchableOpacity, Text, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Container, Header, Left, Body, Content, Button, Title } from 'native-base';
import logo from '../../../assets/images/Complaint/ic_complaint.png';
import { connect } from 'react-redux';
import { addComplaint } from '../../Redux/Actions/complaint/complaint';
import { Toaster } from '../Toaster/Toast';
import LoadingIndicator from '../LoadingIndicator/LoadingIndicator';
class Complaint extends Component {
    state = {
        fname: '',
        lname: '',
        email: '',
        subject: '',
        complaint: '',
        showTost: false,
        isLoading: false
    }
    static navigationOptions = {
        drawerLabel: 'Complaint',
        drawerIcon: () => (
            <View>
                {Platform.OS === 'ios' ?
                    <Ionicons name='ios-volume-high' size={25} color="#5c4c4c" />
                    :
                    <Ionicons name='md-volume-high' size={25} color="#5c4c4c" />
                }
            </View>
        ),
    };
    componentDidMount() {
        StatusBar.setBarStyle('light-content', true)
        StatusBar.setBackgroundColor("#DF0100")
    }
    handleSubmit = () => {
        const { email, _id } = this.props.currentUser
        const { subject, complaint, } = this.state
        const userData = {
            _id,
            email,
            subject,
            complaint
        }
        this.setState({ isLoading: true })
        this.props.dispatch(addComplaint(userData))
        setTimeout(() => {
            this.setState({ isLoading: false })
        }, 3000);
        setTimeout(() => {
            this.setState({ showTost: !this.state.showTost })
        }, 5000);
    }
    render() {
        const { fname, lname, email } = this.props.currentUser
        const { message } = this.props
        const { subject, complaint, showTost, isLoading } = this.state
        if (isLoading) {
            return (
                <LoadingIndicator
                    title="Please wait...."
                />
            )
        }
        return (
            <Container
                style={styles.complaintContainer}
            >
                <Header
                    style={styles.complaintHeader}
                >
                    <Left>
                        <Button transparent
                            onPress={() => this.props.navigation.navigate('Home')}
                        >
                            {Platform.OS === 'ios' ? <Ionicons name="ios-arrow-back" size={32} style={{ color: '#fff' }} /> :
                                <Ionicons name="md-arrow-back" size={32} style={{ color: '#fff' }} />
                            }
                        </Button>
                    </Left>
                    <Body style={{ marginLeft: 40, }}>
                        <Title style={{ marginLeft: 22 }}>Complaint</Title>
                    </Body>
                </Header>
                <Content style={styles.complaintContent}>
                    <Toaster visible={showTost} message={message ? message : ''} />
                    <StatusBar barStyle="dark-content" backgroundColor="#DF0100" />
                    <View style={styles.logoView}>
                        <Image source={logo} style={styles.logoStyle} />
                    </View>
                    <View style={styles.viewFields}>
                        <View>
                            <TextInput
                                style={styles.textInput}
                                placeholder='First Name'
                                value={fname}
                                onChangeText={fname => this.setState({ fname, })}
                            />
                        </View>
                        <View>
                            <TextInput
                                style={styles.textInput}
                                placeholder='Last Name'
                                value={lname}
                                onChangeText={lname => this.setState({ lname, })}
                            />
                        </View>
                        <View>
                            <TextInput
                                placeholder={'Email'}
                                style={styles.textInput}
                                value={email}
                                onChangeText={email => this.setState({ email })}
                            />

                        </View>
                        <View>

                            <TextInput
                                style={styles.textInput}
                                placeholder={'Subject'}
                                value={subject}
                                onChangeText={subject => this.setState({ subject })}
                            />
                        </View>
                        <ScrollView style={{ marginTop: 7 }}>
                            <View>
                                <TextInput
                                    style={styles.commentText}
                                    placeholder={'Complaint....'}
                                    value={complaint}
                                    onChangeText={complaint => this.setState({ complaint })}
                                />
                            </View>

                            {/* <View style={styles.commentView}>
                                <Text style={{ margin: 10, color: '#fff', fontFamily: 'avenirltstd-heavy'}} >
                                {complaint}
                                </Text>
                            </View> */}
                        </ScrollView>

                        <TouchableOpacity
                            onPress={this.handleSubmit}
                        >
                            <View style={styles.signUpBtn}>
                                <Text style={{ color: '#fff', fontSize: 20, fontFamily: 'avenirltstd-heavy' }}>
                                    SUBMIT COMPLAINT
                                </Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                </Content>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    complaintContainer: {
        backgroundColor: '#261010'
    },
    complaintHeader: {
        backgroundColor: 'transparent',
    },
    complaintContent: {
        flex: 1,
    },
    logoView: {
        alignSelf: 'center',
        marginTop: 15
    },
    logoStyle: {
        height: 90,
        width: 90
    },
    viewFields: {
        marginTop: 8,
    },
    textInput: {
        borderRadius: 5,
        borderWidth: 1,
        marginTop: 10,
        height: 50,
        backgroundColor: '#333333',
        marginLeft: 10,
        marginRight: 10,
        paddingLeft: 10,
        color: '#fff',
        fontFamily: 'avenirltstd-heavy'
    },
    signUpBtn: {
        marginTop: 13,
        marginLeft: 10,
        marginRight: 10,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#DF0100',
        height: 50,
        borderWidth: 1,
        borderRadius: 5
    },
    commentText: {
        borderRadius: 5,
        borderWidth: 1,
        margin: 10,
        height: 100,
        backgroundColor: '#333333',
        color: '#fff',
        fontFamily: 'avenirltstd-heavy',
        paddingBottom: 50,
        paddingLeft: 10,
    }
})
const mapStateToProps = (store) => {
    return {
        currentUser: store.auth.currentUser,
        message: store.addComplaint.message
    }
}
export default connect(mapStateToProps)(Complaint)